# Task Manager - Quick Reference

## 🚀 Quick Start Commands

```bash
# Backend Setup
cd backend
npm install
npm run dev

# Frontend Setup (new terminal)
cd frontend
npm install
npm start
```

## 📝 Project Structure

```
task-manager-app/
├── backend/
│   ├── server.js          # Main application
│   ├── middleware/auth.js # Auth middleware
│   ├── utils/validators.js# Validation logic
│   ├── package.json
│   └── .env
└── frontend/
    ├── src/
    │   ├── components/
    │   ├── services/api.js # API service
    │   ├── App.jsx
    │   └── index.js
    ├── package.json
    └── .env
```

## 🔌 Ports

| Service | Port | URL |
|---------|------|-----|
| Backend API | 5000 | http://localhost:5000 |
| Backend WebSocket | 5000 | ws://localhost:5000 |
| Frontend | 3000 | http://localhost:3000 |

## 🔐 Authentication

### Register
```bash
POST /api/auth/register
{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "SecurePass123"
}
```

### Login
```bash
POST /api/auth/login
{
  "email": "john@example.com",
  "password": "SecurePass123"
}
```

### Use Token
```
Authorization: Bearer <token>
```

## 📋 Task Endpoints

| Method | Endpoint | Purpose |
|--------|----------|---------|
| GET | `/api/tasks` | Get all tasks |
| GET | `/api/tasks/:id` | Get single task |
| POST | `/api/tasks` | Create task |
| PUT | `/api/tasks/:id` | Update task |
| DELETE | `/api/tasks/:id` | Delete task |

### Task Object
```javascript
{
  id: 1,
  userId: 1,
  title: "Task title",
  description: "Task description",
  priority: "high", // low, medium, high
  category: "work", // work, personal, health, finance, general
  dueDate: "2026-05-20",
  completed: false,
  createdAt: "2026-05-16T10:00:00Z",
  updatedAt: "2026-05-16T10:00:00Z"
}
```

## 🌐 API Calls (Frontend)

### Using authService
```javascript
import { authService, taskService } from '@/services/api';

// Register
await authService.register({
  name: 'John',
  email: 'john@example.com',
  password: 'Pass123'
});

// Login
await authService.login({
  email: 'john@example.com',
  password: 'Pass123'
});

// Get current user
await authService.getCurrentUser();

// Logout
authService.logout();

// Check auth
authService.isAuthenticated();
```

### Using taskService
```javascript
// Get all tasks
const tasks = await taskService.getAll();

// Get single task
const task = await taskService.getById(1);

// Create task
await taskService.create({
  title: 'New task',
  priority: 'high'
});

// Update task
await taskService.update(1, {
  completed: true
});

// Delete task
await taskService.delete(1);

// Toggle complete
await taskService.toggleComplete(1, true);
```

## 🔄 WebSocket Usage

```javascript
import { wsService } from '@/services/api';

// Connect
await wsService.connect(token);

// Listen to events
wsService.on('task-created', (data) => {
  console.log('New task:', data);
});

wsService.on('task-updated', (data) => {
  console.log('Updated task:', data);
});

wsService.on('task-deleted', (data) => {
  console.log('Deleted task:', data);
});

// Disconnect
wsService.disconnect();
```

## 📦 Dependencies

### Backend
```
express - Web framework
cors - CORS middleware
jsonwebtoken - JWT auth
bcryptjs - Password hashing
ws - WebSocket server
dotenv - Env variables
```

### Frontend
```
react - UI library
react-router-dom - Routing
axios - HTTP client
```

## 🔑 Environment Variables

### Backend (.env)
```
PORT=5000
NODE_ENV=development
JWT_SECRET=your-secret
REFRESH_SECRET=your-refresh-secret
CORS_ORIGIN=http://localhost:3000
```

### Frontend (.env)
```
REACT_APP_API_URL=http://localhost:5000/api
REACT_APP_WS_URL=ws://localhost:5000
```

## 🧪 Testing

### Test with cURL
```bash
# Register
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"John","email":"john@example.com","password":"Pass123"}'

# Get token from response, then:
# Create task
curl -X POST http://localhost:5000/api/tasks \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{"title":"Test Task","priority":"high"}'
```

### Test with Postman
1. Create POST request to http://localhost:5000/api/auth/login
2. Copy token from response
3. Create Authorization header with Bearer token
4. Make requests to task endpoints

## 🐛 Debugging

### Check if ports are running
```bash
# Check port 5000
lsof -i :5000

# Check port 3000
lsof -i :3000

# Kill process (macOS/Linux)
kill -9 <PID>
```

### Clear cache
```javascript
// In browser console
localStorage.clear()
sessionStorage.clear()
```

### View logs
```bash
# Backend logs appear in terminal

# Frontend: Check browser console (F12)
```

## 📊 Status Codes

| Code | Meaning |
|------|---------|
| 200 | OK - Request successful |
| 201 | Created - Resource created |
| 400 | Bad Request - Invalid input |
| 401 | Unauthorized - Auth required |
| 403 | Forbidden - Permission denied |
| 404 | Not Found - Resource not found |
| 409 | Conflict - Resource exists |
| 500 | Server Error - Internal error |

## 🎨 Frontend Components

### Auth Screen
- Email input
- Password input
- Register/Login toggle
- Error display

### Task Dashboard
- Add task form
- Task list
- Filter sidebar
- Statistics panel

### Task Item
- Title
- Description
- Priority badge
- Category tag
- Due date
- Complete/Delete buttons

## 💾 Data Storage

### Local Storage
```javascript
// Store token
localStorage.setItem('token', token);

// Get token
const token = localStorage.getItem('token');

// Remove token
localStorage.removeItem('token');

// Clear all
localStorage.clear();
```

## 🔒 Security Tips

- Change JWT_SECRET in production
- Use HTTPS in production
- Never store passwords in code
- Validate all inputs
- Use environment variables
- Implement rate limiting
- Keep dependencies updated

## 📱 Responsive Breakpoints

```css
Mobile:  < 480px
Tablet:  480px - 768px
Desktop: > 768px
```

## ⚡ Performance Tips

- Use memoization for components
- Lazy load routes
- Optimize bundle size
- Cache API responses
- Use pagination for large lists

## 🚀 Deployment Checklist

- [ ] Update environment variables
- [ ] Build frontend: `npm run build`
- [ ] Test in production mode
- [ ] Set up CORS properly
- [ ] Enable HTTPS
- [ ] Set secure JWT secrets
- [ ] Configure database
- [ ] Set up monitoring
- [ ] Back up database
- [ ] Create deploy guide

## 📚 Useful Links

- [Express Docs](https://expressjs.com/)
- [React Docs](https://react.dev/)
- [JWT Guide](https://jwt.io/)
- [REST API Design](https://restfulapi.net/)
- [WebSocket API](https://developer.mozilla.org/en-US/docs/Web/API/WebSocket)

## 💡 Common Tasks

### Add new task field
1. Update Task CRUD endpoint
2. Update validation in utils/validators.js
3. Update frontend form
4. Update task display component

### Change API URL
Update `.env` file in frontend

### Add authentication to route
```javascript
// Backend
const { authenticateToken } = require('./middleware/auth');
app.get('/api/protected', authenticateToken, (req, res) => {
  // Protected route
});
```

### Test authentication
```javascript
// Frontend
const token = authService.getToken();
if (!token) {
  // Not authenticated
}
```

## 🆘 Quick Fixes

| Issue | Solution |
|-------|----------|
| Port in use | Kill process or change port |
| CORS error | Check CORS_ORIGIN in backend .env |
| Token invalid | Clear localStorage and re-login |
| WebSocket won't connect | Check backend running, check firewall |
| Database error | Check MongoDB is running (if using) |
| Module not found | Run `npm install` again |

## 📞 Support

Check these files for more info:
- README.md - Project overview
- INSTALLATION_GUIDE.md - Setup instructions
- API_DOCUMENTATION.md - API reference
- TESTING_GUIDE.md - Testing procedures

---

**Last Updated:** 2026-05-16
