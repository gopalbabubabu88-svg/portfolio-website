# 📋 Task Management Application - Full Stack

A modern, full-stack task management web application with real-time updates, user authentication, and responsive design.

## 🎯 Project Overview

**Due Date:** 15 May 2026  
**Status:** Development

This is a complete task management system demonstrating:
- ✅ Full-stack architecture (Node.js + React)
- ✅ User authentication & authorization
- ✅ CRUD operations for task management
- ✅ Real-time updates via WebSockets
- ✅ Responsive design (mobile & desktop)
- ✅ Modern UI with smooth animations

## 🏗️ Architecture

```
Task Management App
├── Backend (Node.js/Express)
│   ├── Authentication (JWT)
│   ├── Task CRUD API
│   ├── WebSocket Server
│   └── In-memory Database (upgradeable to MongoDB/PostgreSQL)
└── Frontend (React)
    ├── Authentication UI
    ├── Task Dashboard
    ├── Real-time Updates
    └── Responsive Design
```

## 📁 Project Structure

```
task-management-app/
├── backend/
│   ├── server.js
│   ├── package.json
│   ├── .env
│   └── middleware/
│       └── auth.js
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   ├── App.jsx
│   │   └── index.jsx
│   ├── package.json
│   └── .env
├── docker-compose.yml
├── README.md
└── .gitignore
```

## 🚀 Quick Start

### Prerequisites
- Node.js (v14 or higher)
- npm or yarn
- Git

### 1. Backend Setup

```bash
# Create backend directory
mkdir backend
cd backend

# Initialize and install dependencies
npm init -y
npm install express cors jwt jsonwebtoken bcryptjs ws dotenv

# Create .env file
echo "JWT_SECRET=your-secret-key-here" > .env
echo "PORT=5000" >> .env

# Start server
node server.js
```

### 2. Frontend Setup

```bash
# In a new terminal
npx create-react-app frontend
cd frontend

# Install dependencies (if not included)
npm install axios react-router-dom

# Start frontend
npm start
```

## 🔑 Key Features Explained

### 1. Authentication & Authorization
- **Registration:** New users can create accounts
- **Login:** Secure authentication with JWT tokens
- **Token Storage:** Tokens stored in localStorage
- **Protected Routes:** Only authenticated users can access tasks

```javascript
// Example: Protected API call
const token = localStorage.getItem('token');
const response = await fetch('/api/tasks', {
  headers: { Authorization: `Bearer ${token}` }
});
```

### 2. CRUD Operations
- **Create:** Add new tasks with title, description, priority, category, due date
- **Read:** Fetch all tasks or specific task details
- **Update:** Edit task details or mark as complete
- **Delete:** Remove tasks from the system

### 3. Real-time Updates (WebSocket)
- Instant task updates across multiple browser tabs/devices
- Server broadcasts changes to connected clients
- Automatic sync without page refresh

```javascript
// WebSocket connection
const ws = new WebSocket('ws://localhost:5000');
ws.send(JSON.stringify({ type: 'auth', token }));
```

### 4. Responsive Design
- Mobile-first approach
- Flexible grid layouts
- Touch-friendly buttons
- Adaptive typography

## 📊 API Endpoints

### Authentication
```
POST   /api/auth/register       - Register new user
POST   /api/auth/login          - Login user
GET    /api/auth/me             - Get current user (protected)
```

### Tasks
```
GET    /api/tasks               - Get all user tasks (protected)
GET    /api/tasks/:id           - Get specific task (protected)
POST   /api/tasks               - Create task (protected)
PUT    /api/tasks/:id           - Update task (protected)
DELETE /api/tasks/:id           - Delete task (protected)
```

## 🔐 Authentication Flow

```
1. User Registration
   ├─ Email & Password
   ├─ Password Hashing (bcrypt)
   └─ JWT Token Generation

2. User Login
   ├─ Credentials Validation
   ├─ Password Verification
   └─ Token Issued

3. Protected Requests
   ├─ Include Token in Header
   ├─ Token Verification
   └─ User Context Set
```

## 📱 Responsive Breakpoints

```css
Mobile:     < 480px
Tablet:     480px - 768px
Desktop:    > 768px
```

## 🎨 UI Components

### Authentication Screen
- Email/Password input fields
- Register/Login toggle
- Error message display
- Form validation

### Task Dashboard
- Task creation form
- Task list with filters
- Statistics sidebar
- Task actions (complete, delete, edit)

### Task Item
- Title and description
- Priority badge
- Category tag
- Due date
- Action buttons

## 🔄 Real-time Features

### WebSocket Events
```javascript
// Server → Client
{
  type: 'task-created',
  data: { id, title, ... }
}

{
  type: 'task-updated',
  data: { id, title, completed, ... }
}

{
  type: 'task-deleted',
  data: { id }
}
```

## 🌐 Environment Variables

### Backend (.env)
```
JWT_SECRET=your-secret-key-change-in-production
REFRESH_SECRET=your-refresh-secret-key
PORT=5000
DATABASE_URL=mongodb://localhost/taskmanager (optional)
```

### Frontend (.env)
```
REACT_APP_API_URL=http://localhost:5000/api
REACT_APP_WS_URL=ws://localhost:5000
```

## 📦 Dependencies

### Backend
- **express** - Web framework
- **cors** - Cross-origin requests
- **jsonwebtoken** - JWT authentication
- **bcryptjs** - Password hashing
- **ws** - WebSocket server
- **dotenv** - Environment variables

### Frontend
- **react** - UI library
- **react-dom** - DOM rendering
- **axios** - HTTP client (optional)

## 🧪 Testing the App

### 1. Register a New User
```
POST http://localhost:5000/api/auth/register
{
  "email": "user@example.com",
  "password": "securepassword",
  "name": "John Doe"
}
```

### 2. Login
```
POST http://localhost:5000/api/auth/login
{
  "email": "user@example.com",
  "password": "securepassword"
}
```

### 3. Create a Task
```
POST http://localhost:5000/api/tasks
Headers: Authorization: Bearer <token>
{
  "title": "Complete project documentation",
  "description": "Write comprehensive API docs",
  "priority": "high",
  "category": "work",
  "dueDate": "2026-05-20"
}
```

## 🐛 Troubleshooting

### Port Already in Use
```bash
# On macOS/Linux
lsof -i :5000
kill -9 <PID>

# On Windows
netstat -ano | findstr :5000
taskkill /PID <PID> /F
```

### CORS Issues
Ensure CORS is enabled in Express:
```javascript
app.use(cors());
```

### WebSocket Connection Failed
- Check if server is running on correct port
- Verify firewall settings
- Check browser console for errors

## 🔧 Upgrade Options

### Database Integration
- **MongoDB:** For cloud database
- **PostgreSQL:** For relational data
- **SQLite:** For local development

### Additional Features
- Email notifications
- Task categories and tags
- Collaborative tasks
- File attachments
- Dark mode toggle
- Task reminders

## 📚 Learning Outcomes

This project teaches:
- ✅ Full-stack application architecture
- ✅ RESTful API design
- ✅ JWT authentication
- ✅ WebSocket real-time communication
- ✅ React component design
- ✅ State management
- ✅ Responsive CSS design
- ✅ Async/await and promises
- ✅ Error handling
- ✅ Database integration concepts

## 🚀 Deployment

### Heroku
```bash
heroku create task-manager-app
git push heroku main
```

### Vercel (Frontend)
```bash
vercel
```

### Docker
```bash
docker-compose up
```

## 📖 Additional Resources

- [Express.js Documentation](https://expressjs.com/)
- [React Documentation](https://react.dev/)
- [JWT Introduction](https://jwt.io/introduction)
- [WebSocket API](https://developer.mozilla.org/en-US/docs/Web/API/WebSocket)
- [REST API Design](https://restfulapi.net/)

## 📝 Notes

- Replace in-memory database with real database for production
- Use environment variables for secrets
- Implement input validation
- Add rate limiting
- Enable HTTPS in production
- Set secure cookie flags

## ✨ Features Checklist

- [x] User Registration
- [x] User Login
- [x] Create Tasks
- [x] Read Tasks
- [x] Update Tasks
- [x] Delete Tasks
- [x] Real-time Updates (WebSocket)
- [x] Task Filtering
- [x] Task Statistics
- [x] Responsive Design
- [x] Mobile Support
- [x] Error Handling
- [x] Loading States

## 👨‍💼 Intern Project Success Criteria

✅ **Full-stack application structure** - Demonstrated  
✅ **API integration** - Complete with RESTful endpoints  
✅ **Dynamic data handling** - CRUD operations + real-time updates  
✅ **Authentication & Authorization** - JWT-based security  
✅ **Responsive design** - Mobile and desktop compatible  
✅ **Code documentation** - Inline comments and README  

## 📞 Support

For issues or questions, refer to the inline code comments and troubleshooting section above.

---

**Happy Coding! 🚀**
