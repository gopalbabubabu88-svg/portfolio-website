// Task Management Application - Backend Server
// Node.js/Express API with WebSocket support

const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const dotenv = require('dotenv');

dotenv.config();

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

// Middleware
app.use(cors());
app.use(express.json());

// Secret keys (use environment variables in production)
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';
const REFRESH_SECRET = process.env.REFRESH_SECRET || 'your-refresh-secret-key';

// In-memory database (replace with real database in production)
const users = new Map();
const tasks = new Map();
let userId = 1;
let taskId = 1;

// Store active WebSocket connections
const userConnections = new Map();

// Helper: Generate JWT Token
const generateToken = (user) => {
  return jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '1h' });
};

// Helper: Verify JWT Token
const verifyToken = (token) => {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (err) {
    return null;
  }
};

// Middleware: Authenticate requests
const authenticate = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'No token provided' });

  const decoded = verifyToken(token);
  if (!decoded) return res.status(401).json({ error: 'Invalid token' });

  req.user = decoded;
  next();
};

// ==================== AUTHENTICATION ROUTES ====================

// Register
app.post('/api/auth/register', async (req, res) => {
  const { email, password, name } = req.body;

  if (!email || !password || !name) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  if (users.has(email)) {
    return res.status(409).json({ error: 'User already exists' });
  }

  const hashedPassword = await bcrypt.hash(password, 10);
  const user = {
    id: userId++,
    email,
    name,
    password: hashedPassword,
    createdAt: new Date(),
  };

  users.set(email, user);

  const token = generateToken(user);
  res.status(201).json({
    message: 'User registered successfully',
    token,
    user: { id: user.id, email: user.email, name: user.name },
  });
});

// Login
app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password required' });
  }

  const user = users.get(email);
  if (!user) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  const isPasswordValid = await bcrypt.compare(password, user.password);
  if (!isPasswordValid) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  const token = generateToken(user);
  res.json({
    message: 'Login successful',
    token,
    user: { id: user.id, email: user.email, name: user.name },
  });
});

// Get Current User
app.get('/api/auth/me', authenticate, (req, res) => {
  const user = users.get(Array.from(users.values()).find(u => u.id === req.user.id).email);
  res.json({
    id: user.id,
    email: user.email,
    name: user.name,
  });
});

// ==================== TASK CRUD ROUTES ====================

// Get all tasks for a user
app.get('/api/tasks', authenticate, (req, res) => {
  const userTasks = Array.from(tasks.values()).filter(task => task.userId === req.user.id);
  res.json(userTasks);
});

// Get single task
app.get('/api/tasks/:id', authenticate, (req, res) => {
  const task = tasks.get(parseInt(req.params.id));
  if (!task) return res.status(404).json({ error: 'Task not found' });
  if (task.userId !== req.user.id) return res.status(403).json({ error: 'Unauthorized' });
  res.json(task);
});

// Create task
app.post('/api/tasks', authenticate, (req, res) => {
  const { title, description, priority, dueDate, category } = req.body;

  if (!title) {
    return res.status(400).json({ error: 'Title is required' });
  }

  const task = {
    id: taskId++,
    userId: req.user.id,
    title,
    description: description || '',
    priority: priority || 'medium',
    category: category || 'general',
    dueDate: dueDate || null,
    completed: false,
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  tasks.set(task.id, task);

  // Broadcast to user's WebSocket connections
  broadcastToUser(req.user.id, 'task-created', task);

  res.status(201).json(task);
});

// Update task
app.put('/api/tasks/:id', authenticate, (req, res) => {
  const task = tasks.get(parseInt(req.params.id));
  if (!task) return res.status(404).json({ error: 'Task not found' });
  if (task.userId !== req.user.id) return res.status(403).json({ error: 'Unauthorized' });

  const { title, description, priority, dueDate, category, completed } = req.body;

  Object.assign(task, {
    title: title !== undefined ? title : task.title,
    description: description !== undefined ? description : task.description,
    priority: priority !== undefined ? priority : task.priority,
    dueDate: dueDate !== undefined ? dueDate : task.dueDate,
    category: category !== undefined ? category : task.category,
    completed: completed !== undefined ? completed : task.completed,
    updatedAt: new Date(),
  });

  tasks.set(task.id, task);

  // Broadcast update
  broadcastToUser(req.user.id, 'task-updated', task);

  res.json(task);
});

// Delete task
app.delete('/api/tasks/:id', authenticate, (req, res) => {
  const task = tasks.get(parseInt(req.params.id));
  if (!task) return res.status(404).json({ error: 'Task not found' });
  if (task.userId !== req.user.id) return res.status(403).json({ error: 'Unauthorized' });

  tasks.delete(parseInt(req.params.id));

  // Broadcast deletion
  broadcastToUser(req.user.id, 'task-deleted', { id: task.id });

  res.json({ message: 'Task deleted successfully' });
});

// ==================== WEBSOCKET ====================

wss.on('connection', (ws) => {
  let currentUserId = null;

  ws.on('message', (message) => {
    try {
      const data = JSON.parse(message);

      if (data.type === 'auth') {
        const decoded = verifyToken(data.token);
        if (decoded) {
          currentUserId = decoded.id;
          if (!userConnections.has(currentUserId)) {
            userConnections.set(currentUserId, []);
          }
          userConnections.get(currentUserId).push(ws);
          ws.send(JSON.stringify({ type: 'authenticated', userId: currentUserId }));
        } else {
          ws.close();
        }
      }
    } catch (err) {
      console.error('WebSocket message error:', err);
    }
  });

  ws.on('close', () => {
    if (currentUserId && userConnections.has(currentUserId)) {
      const connections = userConnections.get(currentUserId);
      const index = connections.indexOf(ws);
      if (index > -1) connections.splice(index, 1);
      if (connections.length === 0) userConnections.delete(currentUserId);
    }
  });
});

// Helper: Broadcast to user's connections
const broadcastToUser = (userId, type, data) => {
  const connections = userConnections.get(userId) || [];
  connections.forEach(ws => {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type, data }));
    }
  });
};

// ==================== START SERVER ====================

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`✨ Task Manager Server running on port ${PORT}`);
  console.log(`📡 WebSocket available at ws://localhost:${PORT}`);
});

module.exports = { app, server, wss };
