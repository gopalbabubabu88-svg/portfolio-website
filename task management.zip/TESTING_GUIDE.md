# Task Manager - Testing Guide

## 🧪 Testing Strategy

This guide covers manual testing, API testing, and frontend testing for the task management application.

---

## Manual API Testing

### Setup Postman/Thunder Client

1. Import the API collection
2. Set up environment variables
3. Configure pre-request scripts for token management

### Environment Variables Template

```json
{
  "base_url": "http://localhost:5000/api",
  "ws_url": "ws://localhost:5000",
  "token": "",
  "user_id": "",
  "task_id": ""
}
```

---

## Test Scenarios

### 1. Authentication Flow

#### Test 1.1: User Registration

**Objective:** Verify new users can register successfully

**Steps:**
1. Send POST to `/auth/register`
2. Provide valid credentials
3. Verify token is returned
4. Store token for subsequent requests

**Request:**
```bash
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test User",
    "email": "testuser@example.com",
    "password": "TestPass123"
  }'
```

**Expected Response (201):**
```json
{
  "message": "User registered successfully",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 1,
    "email": "testuser@example.com",
    "name": "Test User"
  }
}
```

**Pass Criteria:**
- ✅ Status code is 201
- ✅ Response contains token
- ✅ User data returned correctly

---

#### Test 1.2: User Login

**Objective:** Verify registered users can login

**Request:**
```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "testuser@example.com",
    "password": "TestPass123"
  }'
```

**Expected Response (200):**
```json
{
  "message": "Login successful",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 1,
    "email": "testuser@example.com",
    "name": "Test User"
  }
}
```

**Pass Criteria:**
- ✅ Status code is 200
- ✅ Token is returned
- ✅ Token differs from registration token (new token issued)

---

#### Test 1.3: Invalid Credentials

**Objective:** Verify login fails with wrong password

**Request:**
```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "testuser@example.com",
    "password": "WrongPassword"
  }'
```

**Expected Response (401):**
```json
{
  "error": "Invalid credentials"
}
```

**Pass Criteria:**
- ✅ Status code is 401
- ✅ No token returned
- ✅ Error message is clear

---

#### Test 1.4: Get Current User

**Objective:** Verify authenticated user can retrieve their profile

**Request:**
```bash
curl -X GET http://localhost:5000/api/auth/me \
  -H "Authorization: Bearer {token}"
```

**Expected Response (200):**
```json
{
  "id": 1,
  "email": "testuser@example.com",
  "name": "Test User"
}
```

**Pass Criteria:**
- ✅ Status code is 200
- ✅ Correct user data returned
- ✅ No sensitive data exposed

---

### 2. Task CRUD Operations

#### Test 2.1: Create Task

**Objective:** Verify authenticated users can create tasks

**Request:**
```bash
curl -X POST http://localhost:5000/api/tasks \
  -H "Authorization: Bearer {token}" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Buy groceries",
    "description": "Milk, eggs, bread, vegetables",
    "priority": "medium",
    "category": "personal",
    "dueDate": "2026-05-20"
  }'
```

**Expected Response (201):**
```json
{
  "id": 1,
  "userId": 1,
  "title": "Buy groceries",
  "description": "Milk, eggs, bread, vegetables",
  "priority": "medium",
  "category": "personal",
  "dueDate": "2026-05-20",
  "completed": false,
  "createdAt": "2026-05-16T10:00:00Z",
  "updatedAt": "2026-05-16T10:00:00Z"
}
```

**Pass Criteria:**
- ✅ Status code is 201
- ✅ Task ID is assigned
- ✅ All fields returned correctly
- ✅ Timestamps are set

---

#### Test 2.2: Create Task Without Title

**Objective:** Verify validation prevents tasks without titles

**Request:**
```bash
curl -X POST http://localhost:5000/api/tasks \
  -H "Authorization: Bearer {token}" \
  -H "Content-Type: application/json" \
  -d '{
    "description": "No title provided",
    "priority": "high"
  }'
```

**Expected Response (400):**
```json
{
  "error": "Title is required"
}
```

**Pass Criteria:**
- ✅ Status code is 400
- ✅ Clear error message
- ✅ Task not created

---

#### Test 2.3: Get All Tasks

**Objective:** Verify users can retrieve all their tasks

**Request:**
```bash
curl -X GET http://localhost:5000/api/tasks \
  -H "Authorization: Bearer {token}"
```

**Expected Response (200):**
```json
[
  {
    "id": 1,
    "title": "Buy groceries",
    "completed": false,
    ...
  },
  {
    "id": 2,
    "title": "Complete project",
    "completed": false,
    ...
  }
]
```

**Pass Criteria:**
- ✅ Status code is 200
- ✅ Array of tasks returned
- ✅ Only user's tasks returned
- ✅ All task properties included

---

#### Test 2.4: Get Single Task

**Objective:** Verify users can retrieve specific tasks

**Request:**
```bash
curl -X GET http://localhost:5000/api/tasks/1 \
  -H "Authorization: Bearer {token}"
```

**Expected Response (200):**
```json
{
  "id": 1,
  "userId": 1,
  "title": "Buy groceries",
  "description": "Milk, eggs, bread, vegetables",
  "priority": "medium",
  "category": "personal",
  "dueDate": "2026-05-20",
  "completed": false,
  "createdAt": "2026-05-16T10:00:00Z",
  "updatedAt": "2026-05-16T10:00:00Z"
}
```

**Pass Criteria:**
- ✅ Status code is 200
- ✅ Correct task returned
- ✅ All fields present

---

#### Test 2.5: Update Task

**Objective:** Verify users can update their tasks

**Request:**
```bash
curl -X PUT http://localhost:5000/api/tasks/1 \
  -H "Authorization: Bearer {token}" \
  -H "Content-Type: application/json" \
  -d '{
    "completed": true,
    "priority": "low"
  }'
```

**Expected Response (200):**
```json
{
  "id": 1,
  "completed": true,
  "priority": "low",
  "updatedAt": "2026-05-16T11:00:00Z",
  ...
}
```

**Pass Criteria:**
- ✅ Status code is 200
- ✅ Fields updated correctly
- ✅ updatedAt timestamp changed
- ✅ Other fields unchanged

---

#### Test 2.6: Delete Task

**Objective:** Verify users can delete their tasks

**Request:**
```bash
curl -X DELETE http://localhost:5000/api/tasks/1 \
  -H "Authorization: Bearer {token}"
```

**Expected Response (200):**
```json
{
  "message": "Task deleted successfully"
}
```

**Pass Criteria:**
- ✅ Status code is 200
- ✅ Success message returned
- ✅ GET request to same task returns 404

---

### 3. Authorization Tests

#### Test 3.1: Access Without Token

**Objective:** Verify endpoints require authentication

**Request:**
```bash
curl -X GET http://localhost:5000/api/tasks
```

**Expected Response (401):**
```json
{
  "error": "No token provided"
}
```

**Pass Criteria:**
- ✅ Status code is 401
- ✅ Clear error message

---

#### Test 3.2: Invalid Token

**Objective:** Verify invalid tokens are rejected

**Request:**
```bash
curl -X GET http://localhost:5000/api/tasks \
  -H "Authorization: Bearer invalid.token.here"
```

**Expected Response (401):**
```json
{
  "error": "Invalid token"
}
```

**Pass Criteria:**
- ✅ Status code is 401
- ✅ Request rejected

---

#### Test 3.3: Access Other User's Task

**Objective:** Verify users can't access other users' tasks

**Setup:**
1. Create Task with User A
2. Try to access with User B token

**Expected Response (403):**
```json
{
  "error": "Unauthorized"
}
```

**Pass Criteria:**
- ✅ Status code is 403
- ✅ Task not accessible

---

### 4. WebSocket Tests

#### Test 4.1: Connect WebSocket

**Objective:** Verify WebSocket connection works

```javascript
const ws = new WebSocket('ws://localhost:5000');

ws.onopen = () => {
  console.log('Connected');
  ws.send(JSON.stringify({
    type: 'auth',
    token: 'YOUR_TOKEN'
  }));
};

ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  console.log('Received:', data.type);
};
```

**Pass Criteria:**
- ✅ Connection established
- ✅ Authentication successful
- ✅ Ready for messages

---

#### Test 4.2: Real-time Task Creation

**Objective:** Verify real-time updates on task creation

**Setup:**
1. Open 2 browser tabs with same account
2. Create task in Tab 1
3. Verify update appears in Tab 2 without refresh

**Expected Behavior:**
- ✅ New task appears instantly in Tab 2
- ✅ Task data matches creation request

---

#### Test 4.3: Real-time Task Update

**Objective:** Verify task updates are broadcast in real-time

**Steps:**
1. Create task
2. Update task in Tab 1
3. Verify update appears in Tab 2

**Expected Behavior:**
- ✅ Updated task appears instantly
- ✅ All fields updated correctly

---

### 5. Frontend Tests

#### Test 5.1: Register Flow

**Steps:**
1. Open localhost:3000
2. Click Register tab
3. Fill in form with valid data
4. Submit

**Expected Behavior:**
- ✅ Form validates input
- ✅ Success message shown
- ✅ Redirected to dashboard
- ✅ User info displayed

---

#### Test 5.2: Login Flow

**Steps:**
1. Open localhost:3000
2. Enter valid credentials
3. Click Login

**Expected Behavior:**
- ✅ Form validates input
- ✅ Success message shown
- ✅ Redirected to dashboard
- ✅ Tasks displayed

---

#### Test 5.3: Create Task

**Steps:**
1. Login to app
2. Enter task title
3. Select priority
4. Enter due date
5. Click Add Task

**Expected Behavior:**
- ✅ Form validates input
- ✅ Task appears in list
- ✅ Form clears
- ✅ Real-time update works

---

#### Test 5.4: Complete Task

**Steps:**
1. Click Done button on task
2. Verify task is marked complete

**Expected Behavior:**
- ✅ Task grayed out
- ✅ Task title struck through
- ✅ Real-time sync works

---

#### Test 5.5: Delete Task

**Steps:**
1. Click Delete button
2. Confirm deletion

**Expected Behavior:**
- ✅ Task removed from list
- ✅ Real-time sync works

---

## Performance Testing

### Load Test (Future)

Test server with multiple concurrent users:

```bash
# Using Apache Bench
ab -n 1000 -c 100 http://localhost:5000/api/tasks

# Using Artillery
artillery run load-test.yml
```

### Response Time Target

- Authentication: < 200ms
- Task CRUD: < 100ms
- List all tasks: < 500ms

---

## Test Data

### Test Users

```json
{
  "user1": {
    "email": "test1@example.com",
    "password": "Test@1234",
    "name": "Test User 1"
  },
  "user2": {
    "email": "test2@example.com",
    "password": "Test@5678",
    "name": "Test User 2"
  }
}
```

### Test Tasks

```json
{
  "task1": {
    "title": "Buy groceries",
    "description": "Milk, eggs, bread",
    "priority": "medium",
    "category": "personal",
    "dueDate": "2026-05-20"
  },
  "task2": {
    "title": "Complete project",
    "description": "Finish API development",
    "priority": "high",
    "category": "work",
    "dueDate": "2026-05-18"
  }
}
```

---

## Automated Testing (Jest/Supertest)

```javascript
// Example: __tests__/tasks.test.js

const request = require('supertest');
const app = require('../server');

describe('Task Endpoints', () => {
  let token;
  
  beforeAll(async () => {
    const res = await request(app)
      .post('/api/auth/login')
      .send({
        email: 'test@example.com',
        password: 'Test@1234'
      });
    token = res.body.token;
  });

  test('Create task', async () => {
    const res = await request(app)
      .post('/api/tasks')
      .set('Authorization', `Bearer ${token}`)
      .send({
        title: 'Test Task',
        priority: 'high'
      });
    
    expect(res.status).toBe(201);
    expect(res.body.title).toBe('Test Task');
  });

  test('Get all tasks', async () => {
    const res = await request(app)
      .get('/api/tasks')
      .set('Authorization', `Bearer ${token}`);
    
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });
});
```

---

## Checklist for Full Testing

- [ ] All authentication endpoints
- [ ] All CRUD operations
- [ ] Authorization checks
- [ ] Input validation
- [ ] WebSocket connection
- [ ] Real-time updates
- [ ] Frontend UI interactions
- [ ] Responsive design
- [ ] Error handling
- [ ] Performance metrics

---

## Troubleshooting Test Failures

### Token Issues
```javascript
// Clear token
localStorage.clear()

// Re-login
// OR manually set token in localStorage
localStorage.setItem('token', 'new_token')
```

### WebSocket Connection Failed
1. Check backend is running
2. Check port 5000 is accessible
3. Check firewall settings
4. Check browser console for errors

### Task Not Appearing
1. Verify authentication token
2. Check task was created (check response)
3. Clear cache and refresh
4. Check browser console for errors

---

## Reports

### Test Results Template

```markdown
| Test | Status | Duration | Notes |
|------|--------|----------|-------|
| Auth - Register | ✅ Pass | 150ms | - |
| Auth - Login | ✅ Pass | 120ms | - |
| Task - Create | ✅ Pass | 80ms | - |
| Task - Read | ✅ Pass | 50ms | - |
| Task - Update | ✅ Pass | 90ms | - |
| Task - Delete | ✅ Pass | 70ms | - |
| WebSocket | ✅ Pass | - | Real-time sync works |
```

---

**Happy Testing! 🧪**
