# Task Manager API Documentation

## Overview

Complete RESTful API for task management with user authentication, real-time updates via WebSocket, and comprehensive task management capabilities.

**Base URL:** `http://localhost:5000/api`  
**WebSocket URL:** `ws://localhost:5000`

## Authentication

All protected endpoints require a JWT token in the Authorization header.

### Header Format
```
Authorization: Bearer <token>
```

### Token Storage
Tokens are returned from login/register endpoints and should be stored in `localStorage` on the client.

---

## Endpoints

### Authentication Endpoints

#### 1. Register User

Creates a new user account.

**Endpoint:** `POST /auth/register`

**Request Body:**
```json
{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "SecurePass123"
}
```

**Response (201):**
```json
{
  "message": "User registered successfully",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 1,
    "email": "john@example.com",
    "name": "John Doe"
  }
}
```

**Error Responses:**
- `400 Bad Request` - Missing required fields
- `409 Conflict` - User already exists

**Curl Example:**
```bash
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "John Doe",
    "email": "john@example.com",
    "password": "SecurePass123"
  }'
```

---

#### 2. Login User

Authenticates a user and returns a JWT token.

**Endpoint:** `POST /auth/login`

**Request Body:**
```json
{
  "email": "john@example.com",
  "password": "SecurePass123"
}
```

**Response (200):**
```json
{
  "message": "Login successful",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 1,
    "email": "john@example.com",
    "name": "John Doe"
  }
}
```

**Error Responses:**
- `400 Bad Request` - Missing email or password
- `401 Unauthorized` - Invalid credentials

**Curl Example:**
```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "john@example.com",
    "password": "SecurePass123"
  }'
```

---

#### 3. Get Current User

Retrieves the authenticated user's information.

**Endpoint:** `GET /auth/me`

**Authentication:** Required

**Response (200):**
```json
{
  "id": 1,
  "email": "john@example.com",
  "name": "John Doe"
}
```

**Error Responses:**
- `401 Unauthorized` - No token or invalid token

**Curl Example:**
```bash
curl -X GET http://localhost:5000/api/auth/me \
  -H "Authorization: Bearer YOUR_TOKEN"
```

---

### Task Endpoints

#### 4. Get All Tasks

Retrieves all tasks for the authenticated user.

**Endpoint:** `GET /tasks`

**Authentication:** Required

**Query Parameters:** (Optional)
- `priority` - Filter by priority (low, medium, high)
- `completed` - Filter by completion status (true/false)
- `category` - Filter by category

**Response (200):**
```json
[
  {
    "id": 1,
    "userId": 1,
    "title": "Complete project documentation",
    "description": "Write comprehensive API docs",
    "priority": "high",
    "category": "work",
    "dueDate": "2026-05-20",
    "completed": false,
    "createdAt": "2026-05-16T10:30:00Z",
    "updatedAt": "2026-05-16T10:30:00Z"
  },
  {
    "id": 2,
    "userId": 1,
    "title": "Review pull requests",
    "description": "Review team's PR submissions",
    "priority": "medium",
    "category": "work",
    "dueDate": "2026-05-17",
    "completed": false,
    "createdAt": "2026-05-16T10:35:00Z",
    "updatedAt": "2026-05-16T10:35:00Z"
  }
]
```

**Error Responses:**
- `401 Unauthorized` - No token or invalid token

**Curl Example:**
```bash
curl -X GET http://localhost:5000/api/tasks \
  -H "Authorization: Bearer YOUR_TOKEN"
```

---

#### 5. Get Single Task

Retrieves a specific task by ID.

**Endpoint:** `GET /tasks/:id`

**Authentication:** Required

**Parameters:**
- `id` (path) - Task ID

**Response (200):**
```json
{
  "id": 1,
  "userId": 1,
  "title": "Complete project documentation",
  "description": "Write comprehensive API docs",
  "priority": "high",
  "category": "work",
  "dueDate": "2026-05-20",
  "completed": false,
  "createdAt": "2026-05-16T10:30:00Z",
  "updatedAt": "2026-05-16T10:30:00Z"
}
```

**Error Responses:**
- `401 Unauthorized` - No token or invalid token
- `403 Forbidden` - Task belongs to another user
- `404 Not Found` - Task not found

**Curl Example:**
```bash
curl -X GET http://localhost:5000/api/tasks/1 \
  -H "Authorization: Bearer YOUR_TOKEN"
```

---

#### 6. Create Task

Creates a new task.

**Endpoint:** `POST /tasks`

**Authentication:** Required

**Request Body:**
```json
{
  "title": "Complete project documentation",
  "description": "Write comprehensive API docs",
  "priority": "high",
  "category": "work",
  "dueDate": "2026-05-20"
}
```

**Field Details:**
- `title` (required, string, max 255 chars) - Task title
- `description` (optional, string, max 5000 chars) - Task description
- `priority` (optional, enum: low/medium/high, default: medium) - Task priority
- `category` (optional, enum: work/personal/health/finance/general, default: general) - Task category
- `dueDate` (optional, string, ISO date format) - Task due date

**Response (201):**
```json
{
  "id": 3,
  "userId": 1,
  "title": "Complete project documentation",
  "description": "Write comprehensive API docs",
  "priority": "high",
  "category": "work",
  "dueDate": "2026-05-20",
  "completed": false,
  "createdAt": "2026-05-16T10:40:00Z",
  "updatedAt": "2026-05-16T10:40:00Z"
}
```

**Error Responses:**
- `400 Bad Request` - Invalid input data
- `401 Unauthorized` - No token or invalid token

**Curl Example:**
```bash
curl -X POST http://localhost:5000/api/tasks \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Complete project documentation",
    "description": "Write comprehensive API docs",
    "priority": "high",
    "category": "work",
    "dueDate": "2026-05-20"
  }'
```

---

#### 7. Update Task

Updates an existing task.

**Endpoint:** `PUT /tasks/:id`

**Authentication:** Required

**Parameters:**
- `id` (path) - Task ID

**Request Body:** (All fields optional)
```json
{
  "title": "Updated title",
  "description": "Updated description",
  "priority": "medium",
  "category": "personal",
  "dueDate": "2026-05-25",
  "completed": true
}
```

**Response (200):**
```json
{
  "id": 1,
  "userId": 1,
  "title": "Updated title",
  "description": "Updated description",
  "priority": "medium",
  "category": "personal",
  "dueDate": "2026-05-25",
  "completed": true,
  "createdAt": "2026-05-16T10:30:00Z",
  "updatedAt": "2026-05-16T11:00:00Z"
}
```

**Error Responses:**
- `400 Bad Request` - Invalid input data
- `401 Unauthorized` - No token or invalid token
- `403 Forbidden` - Task belongs to another user
- `404 Not Found` - Task not found

**Curl Example:**
```bash
curl -X PUT http://localhost:5000/api/tasks/1 \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "completed": true
  }'
```

---

#### 8. Delete Task

Deletes a task.

**Endpoint:** `DELETE /tasks/:id`

**Authentication:** Required

**Parameters:**
- `id` (path) - Task ID

**Response (200):**
```json
{
  "message": "Task deleted successfully"
}
```

**Error Responses:**
- `401 Unauthorized` - No token or invalid token
- `403 Forbidden` - Task belongs to another user
- `404 Not Found` - Task not found

**Curl Example:**
```bash
curl -X DELETE http://localhost:5000/api/tasks/1 \
  -H "Authorization: Bearer YOUR_TOKEN"
```

---

## WebSocket Events

Real-time task updates via WebSocket connection.

### Connection

```javascript
const ws = new WebSocket('ws://localhost:5000');

ws.onopen = () => {
  // Send authentication token
  ws.send(JSON.stringify({
    type: 'auth',
    token: 'YOUR_JWT_TOKEN'
  }));
};

ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  console.log(data.type); // task-created, task-updated, task-deleted
};
```

### Events

#### Task Created
```json
{
  "type": "task-created",
  "data": {
    "id": 3,
    "userId": 1,
    "title": "New task",
    "completed": false,
    "createdAt": "2026-05-16T10:40:00Z"
  }
}
```

#### Task Updated
```json
{
  "type": "task-updated",
  "data": {
    "id": 1,
    "userId": 1,
    "title": "Updated title",
    "completed": true,
    "updatedAt": "2026-05-16T11:00:00Z"
  }
}
```

#### Task Deleted
```json
{
  "type": "task-deleted",
  "data": {
    "id": 1
  }
}
```

---

## Error Response Format

All error responses follow this format:

```json
{
  "error": "Error message",
  "code": "ERROR_CODE",
  "status": 400
}
```

### Common Error Codes

| Code | Status | Description |
|------|--------|-------------|
| NO_TOKEN | 401 | No token provided |
| TOKEN_EXPIRED | 401 | Token has expired |
| INVALID_TOKEN | 401 | Invalid token format |
| UNAUTHORIZED | 401 | User not authenticated |
| FORBIDDEN | 403 | User not authorized for resource |
| NOT_FOUND | 404 | Resource not found |
| VALIDATION_ERROR | 400 | Invalid input data |
| CONFLICT | 409 | Resource already exists |
| SERVER_ERROR | 500 | Internal server error |

---

## Rate Limiting

API implements rate limiting to prevent abuse:

- **Window:** 15 minutes
- **Max Requests:** 100 per window
- **Headers:** Include `X-RateLimit-*` headers in response

---

## Examples by Language

### JavaScript (Fetch API)

```javascript
// Register
const response = await fetch('http://localhost:5000/api/auth/register', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    name: 'John Doe',
    email: 'john@example.com',
    password: 'SecurePass123'
  })
});
const data = await response.json();
localStorage.setItem('token', data.token);

// Create Task
const taskResponse = await fetch('http://localhost:5000/api/tasks', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${data.token}`
  },
  body: JSON.stringify({
    title: 'New Task',
    priority: 'high'
  })
});
```

### JavaScript (Axios)

```javascript
// Setup
import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:5000/api'
});

api.interceptors.request.use(config => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Create Task
api.post('/tasks', {
  title: 'New Task',
  priority: 'high'
});
```

### Python (Requests)

```python
import requests
import json

BASE_URL = 'http://localhost:5000/api'

# Register
response = requests.post(f'{BASE_URL}/auth/register', json={
    'name': 'John Doe',
    'email': 'john@example.com',
    'password': 'SecurePass123'
})
token = response.json()['token']

# Create Task
headers = {'Authorization': f'Bearer {token}'}
response = requests.post(f'{BASE_URL}/tasks', 
    json={'title': 'New Task', 'priority': 'high'},
    headers=headers
)
```

---

## Pagination (Future)

Future versions will support pagination:

```
GET /tasks?page=1&limit=10
GET /tasks?skip=0&take=10
```

---

## Sorting (Future)

Future versions will support sorting:

```
GET /tasks?sort=-createdAt
GET /tasks?sortBy=dueDate&sortOrder=asc
```

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | 2026-05-16 | Initial release |

---

## Support

For API support and issues, refer to:
- GitHub Issues
- Documentation
- Email: support@taskmanager.com

---

**Last Updated:** 2026-05-16
