// middleware/auth.js - Authentication Middleware

const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';

/**
 * Middleware: Verify JWT Token
 * Extracts and validates token from Authorization header
 * Adds user info to request object
 */
const authenticateToken = (req, res, next) => {
  try {
    // Get token from Authorization header
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'Access token required. Please login first.',
        code: 'NO_TOKEN',
      });
    }

    // Verify token
    jwt.verify(token, JWT_SECRET, (err, user) => {
      if (err) {
        console.error('Token verification error:', err.message);
        
        if (err.name === 'TokenExpiredError') {
          return res.status(401).json({
            success: false,
            message: 'Token has expired. Please login again.',
            code: 'TOKEN_EXPIRED',
          });
        }
        
        if (err.name === 'JsonWebTokenError') {
          return res.status(401).json({
            success: false,
            message: 'Invalid token. Please login again.',
            code: 'INVALID_TOKEN',
          });
        }
        
        return res.status(500).json({
          success: false,
          message: 'Token verification failed.',
          code: 'TOKEN_VERIFICATION_FAILED',
        });
      }

      // Add user to request
      req.user = user;
      next();
    });
  } catch (error) {
    console.error('Authentication middleware error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error during authentication.',
      code: 'AUTH_ERROR',
    });
  }
};

/**
 * Middleware: Optional Authentication
 * Does not block requests but adds user if token is valid
 */
const optionalAuth = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (token) {
    jwt.verify(token, JWT_SECRET, (err, user) => {
      if (!err) {
        req.user = user;
      }
      next();
    });
  } else {
    next();
  }
};

/**
 * Middleware: Check User Authorization
 * Verifies that user can only access their own resources
 */
const authorizeUser = (req, res, next) => {
  // This is typically checked in individual routes
  // based on resource ownership
  next();
};

/**
 * Middleware: Error Handler for Authentication
 */
const authErrorHandler = (err, req, res, next) => {
  if (err.name === 'UnauthorizedError') {
    return res.status(401).json({
      success: false,
      message: 'Unauthorized access.',
      code: 'UNAUTHORIZED',
    });
  }
  next(err);
};

/**
 * Generate JWT Token
 * @param {Object} payload - Data to encode in token
 * @param {String} expiresIn - Token expiration time (default: '1h')
 * @returns {String} JWT token
 */
const generateToken = (payload, expiresIn = '1h') => {
  try {
    const token = jwt.sign(payload, JWT_SECRET, {
      expiresIn,
      algorithm: 'HS256',
    });
    return token;
  } catch (error) {
    console.error('Token generation error:', error);
    throw error;
  }
};

/**
 * Generate Refresh Token
 * Longer-lived token for refreshing access tokens
 */
const generateRefreshToken = (payload) => {
  const REFRESH_SECRET = process.env.REFRESH_SECRET || 'your-refresh-secret-key';
  try {
    const token = jwt.sign(payload, REFRESH_SECRET, {
      expiresIn: '7d',
      algorithm: 'HS256',
    });
    return token;
  } catch (error) {
    console.error('Refresh token generation error:', error);
    throw error;
  }
};

/**
 * Verify Refresh Token
 */
const verifyRefreshToken = (token) => {
  const REFRESH_SECRET = process.env.REFRESH_SECRET || 'your-refresh-secret-key';
  try {
    return jwt.verify(token, REFRESH_SECRET);
  } catch (error) {
    console.error('Refresh token verification error:', error);
    return null;
  }
};

/**
 * Decode Token (without verification)
 * Useful for getting user info from token
 */
const decodeToken = (token) => {
  try {
    return jwt.decode(token);
  } catch (error) {
    console.error('Token decode error:', error);
    return null;
  }
};

module.exports = {
  authenticateToken,
  optionalAuth,
  authorizeUser,
  authErrorHandler,
  generateToken,
  generateRefreshToken,
  verifyRefreshToken,
  decodeToken,
};
