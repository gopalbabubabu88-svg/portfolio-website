import React, { useState, useEffect, useRef } from 'react';

// ==================== STYLES ====================
const styles = `
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }

  :root {
    --primary-pink: #ff1493;
    --light-pink: #ffb6d9;
    --dark-pink: #d91e63;
    --soft-pink: #ffc0e6;
    --pale-pink: #ffe4f5;
    --white: #ffffff;
    --dark-text: #2d2d2d;
    --light-gray: #f5f5f5;
    --border-color: #ffb6d9;
  }

  body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(135deg, var(--pale-pink) 0%, #fff5f9 100%);
    min-height: 100vh;
    color: var(--dark-text);
  }

  /* ===== AUTHENTICATION SCREENS ===== */
  .auth-container {
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #ff69b4 0%, #ff1493 50%, #d91e63 100%);
    padding: 20px;
  }

  .auth-box {
    background: var(--white);
    padding: 40px;
    border-radius: 20px;
    box-shadow: 0 20px 60px rgba(255, 20, 147, 0.3);
    width: 100%;
    max-width: 400px;
    animation: slideUp 0.6s ease-out;
  }

  @keyframes slideUp {
    from {
      opacity: 0;
      transform: translateY(30px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  .auth-box h1 {
    font-size: 28px;
    margin-bottom: 10px;
    background: linear-gradient(135deg, var(--primary-pink), var(--dark-pink));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
  }

  .auth-box p {
    font-size: 14px;
    color: #888;
    margin-bottom: 30px;
  }

  .form-group {
    margin-bottom: 20px;
  }

  .form-group label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
    color: var(--dark-text);
    font-size: 14px;
  }

  .form-group input {
    width: 100%;
    padding: 12px 15px;
    border: 2px solid var(--border-color);
    border-radius: 10px;
    font-size: 14px;
    transition: all 0.3s ease;
  }

  .form-group input:focus {
    outline: none;
    border-color: var(--primary-pink);
    box-shadow: 0 0 0 3px rgba(255, 20, 147, 0.1);
  }

  .btn {
    width: 100%;
    padding: 12px;
    border: none;
    border-radius: 10px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
  }

  .btn-primary {
    background: linear-gradient(135deg, var(--primary-pink), var(--dark-pink));
    color: var(--white);
  }

  .btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(255, 20, 147, 0.4);
  }

  .btn-secondary {
    background: var(--light-gray);
    color: var(--dark-text);
    margin-top: 10px;
  }

  .btn-secondary:hover {
    background: #e0e0e0;
  }

  .toggle-text {
    text-align: center;
    margin-top: 20px;
    font-size: 14px;
    color: #888;
  }

  .toggle-text button {
    background: none;
    border: none;
    color: var(--primary-pink);
    font-weight: 600;
    cursor: pointer;
    text-decoration: underline;
  }

  .error-message {
    background: #ffe0e0;
    color: #d91e63;
    padding: 12px;
    border-radius: 8px;
    margin-bottom: 20px;
    font-size: 14px;
  }

  /* ===== MAIN APP ===== */
  .app-container {
    min-height: 100vh;
    background: linear-gradient(135deg, var(--pale-pink) 0%, #fff5f9 100%);
    padding: 20px;
  }

  .header {
    max-width: 1200px;
    margin: 0 auto 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: var(--white);
    padding: 20px 30px;
    border-radius: 15px;
    box-shadow: 0 5px 20px rgba(255, 20, 147, 0.1);
  }

  .header h1 {
    font-size: 28px;
    background: linear-gradient(135deg, var(--primary-pink), var(--dark-pink));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
  }

  .header-right {
    display: flex;
    align-items: center;
    gap: 20px;
  }

  .user-info {
    text-align: right;
  }

  .user-info p {
    font-size: 14px;
    color: #888;
  }

  .user-info strong {
    color: var(--dark-text);
    display: block;
  }

  .btn-logout {
    padding: 10px 20px;
    background: var(--light-pink);
    color: var(--dark-text);
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-weight: 600;
    transition: all 0.3s ease;
  }

  .btn-logout:hover {
    background: var(--primary-pink);
    color: var(--white);
  }

  /* ===== MAIN CONTENT ===== */
  .main-content {
    max-width: 1200px;
    margin: 0 auto;
    display: grid;
    grid-template-columns: 1fr 3fr;
    gap: 20px;
  }

  /* ===== SIDEBAR ===== */
  .sidebar {
    background: var(--white);
    padding: 25px;
    border-radius: 15px;
    box-shadow: 0 5px 20px rgba(255, 20, 147, 0.1);
    height: fit-content;
  }

  .sidebar h3 {
    color: var(--primary-pink);
    font-size: 16px;
    margin-bottom: 15px;
    text-transform: uppercase;
    letter-spacing: 1px;
  }

  .filter-btn {
    display: block;
    width: 100%;
    text-align: left;
    padding: 12px 15px;
    margin-bottom: 8px;
    background: var(--light-gray);
    border: 2px solid transparent;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s ease;
    font-size: 14px;
  }

  .filter-btn.active {
    background: linear-gradient(135deg, var(--primary-pink), var(--dark-pink));
    color: var(--white);
    border-color: var(--primary-pink);
  }

  .filter-btn:hover {
    border-color: var(--primary-pink);
  }

  .stats {
    margin-top: 30px;
    padding-top: 30px;
    border-top: 2px solid var(--soft-pink);
  }

  .stat-item {
    display: flex;
    justify-content: space-between;
    margin-bottom: 15px;
    font-size: 14px;
  }

  .stat-number {
    font-weight: 700;
    color: var(--primary-pink);
    font-size: 18px;
  }

  /* ===== TASK SECTION ===== */
  .task-section {
    background: var(--white);
    padding: 30px;
    border-radius: 15px;
    box-shadow: 0 5px 20px rgba(255, 20, 147, 0.1);
  }

  .task-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 25px;
  }

  .task-header h2 {
    font-size: 22px;
    color: var(--dark-text);
  }

  /* ===== ADD TASK FORM ===== */
  .add-task-form {
    background: linear-gradient(135deg, var(--pale-pink), #fff5f9);
    padding: 20px;
    border-radius: 12px;
    margin-bottom: 25px;
    border: 2px solid var(--border-color);
  }

  .form-row {
    display: grid;
    grid-template-columns: 2fr 1fr 1fr;
    gap: 15px;
    margin-bottom: 15px;
  }

  @media (max-width: 768px) {
    .form-row {
      grid-template-columns: 1fr;
    }

    .main-content {
      grid-template-columns: 1fr;
    }
  }

  .form-input {
    padding: 12px 15px;
    border: 2px solid var(--border-color);
    border-radius: 8px;
    font-size: 14px;
    transition: all 0.3s ease;
  }

  .form-input:focus {
    outline: none;
    border-color: var(--primary-pink);
    box-shadow: 0 0 0 3px rgba(255, 20, 147, 0.1);
  }

  .btn-add-task {
    padding: 12px 25px;
    background: linear-gradient(135deg, var(--primary-pink), var(--dark-pink));
    color: var(--white);
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-weight: 600;
    transition: all 0.3s ease;
  }

  .btn-add-task:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(255, 20, 147, 0.4);
  }

  /* ===== TASKS LIST ===== */
  .tasks-list {
    display: flex;
    flex-direction: column;
    gap: 15px;
  }

  .task-item {
    background: var(--light-gray);
    padding: 20px;
    border-radius: 12px;
    border-left: 5px solid var(--primary-pink);
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    transition: all 0.3s ease;
    animation: fadeIn 0.4s ease;
  }

  @keyframes fadeIn {
    from {
      opacity: 0;
      transform: translateY(10px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  .task-item:hover {
    box-shadow: 0 8px 20px rgba(255, 20, 147, 0.2);
    transform: translateY(-2px);
  }

  .task-item.completed {
    opacity: 0.6;
    background: #f0f0f0;
  }

  .task-item.completed .task-title {
    text-decoration: line-through;
    color: #999;
  }

  .task-content {
    flex: 1;
  }

  .task-title {
    font-size: 16px;
    font-weight: 600;
    color: var(--dark-text);
    margin-bottom: 8px;
  }

  .task-description {
    font-size: 13px;
    color: #666;
    margin-bottom: 10px;
  }

  .task-meta {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
  }

  .task-badge {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
  }

  .badge-priority {
    background: var(--soft-pink);
    color: var(--dark-pink);
  }

  .badge-category {
    background: #e0f7f4;
    color: #00897b;
  }

  .badge-due {
    background: #fff3e0;
    color: #e65100;
  }

  .task-actions {
    display: flex;
    gap: 10px;
  }

  .icon-btn {
    padding: 8px 12px;
    background: var(--white);
    border: 2px solid var(--border-color);
    border-radius: 6px;
    cursor: pointer;
    transition: all 0.3s ease;
    font-size: 12px;
  }

  .icon-btn:hover {
    background: var(--primary-pink);
    color: var(--white);
    border-color: var(--primary-pink);
  }

  /* ===== EMPTY STATE ===== */
  .empty-state {
    text-align: center;
    padding: 60px 20px;
    color: #999;
  }

  .empty-state-icon {
    font-size: 48px;
    margin-bottom: 20px;
  }

  .empty-state h3 {
    font-size: 18px;
    margin-bottom: 10px;
    color: var(--dark-text);
  }

  /* ===== MODAL ===== */
  .modal-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    z-index: 1000;
    justify-content: center;
    align-items: center;
  }

  .modal-overlay.active {
    display: flex;
    animation: fadeIn 0.3s ease;
  }

  .modal {
    background: var(--white);
    padding: 40px;
    border-radius: 15px;
    max-width: 500px;
    width: 90%;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
    animation: slideUp 0.3s ease;
  }

  .modal h2 {
    color: var(--primary-pink);
    margin-bottom: 20px;
  }

  .modal-buttons {
    display: flex;
    gap: 10px;
    margin-top: 20px;
  }

  .btn-cancel {
    flex: 1;
    padding: 12px;
    background: var(--light-gray);
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-weight: 600;
  }

  .btn-confirm {
    flex: 1;
    padding: 12px;
    background: linear-gradient(135deg, var(--primary-pink), var(--dark-pink));
    color: var(--white);
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-weight: 600;
  }

  /* ===== RESPONSIVE ===== */
  @media (max-width: 768px) {
    .header {
      flex-direction: column;
      gap: 15px;
      text-align: center;
    }

    .form-row {
      grid-template-columns: 1fr;
    }

    .task-item {
      flex-direction: column;
    }

    .task-actions {
      width: 100%;
      margin-top: 15px;
    }
  }
`;

// ==================== COMPONENTS ====================

const AuthScreen = ({ onLogin, onRegisterToggle, isRegister }) => {
  const [formData, setFormData] = useState({ email: '', password: '', name: '' });
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    onLogin(formData, isRegister);
  };

  return (
    <div className="auth-container">
      <div className="auth-box">
        <h1>{isRegister ? '✨ Create Account' : '👋 Welcome Back'}</h1>
        <p>{isRegister ? 'Join our task management community' : 'Manage your tasks efficiently'}</p>

        {error && <div className="error-message">{error}</div>}

        <form onSubmit={handleSubmit}>
          {isRegister && (
            <div className="form-group">
              <label>Name</label>
              <input
                type="text"
                placeholder="Your name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
            </div>
          )}

          <div className="form-group">
            <label>Email</label>
            <input
              type="email"
              placeholder="you@example.com"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              required
            />
          </div>

          <div className="form-group">
            <label>Password</label>
            <input
              type="password"
              placeholder="••••••••"
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              required
            />
          </div>

          <button type="submit" className="btn btn-primary">
            {isRegister ? '🚀 Create Account' : '🔓 Login'}
          </button>
        </form>

        <div className="toggle-text">
          {isRegister ? 'Already have an account?' : "Don't have an account?"}{' '}
          <button onClick={onRegisterToggle}>
            {isRegister ? 'Login' : 'Register'}
          </button>
        </div>
      </div>
    </div>
  );
};

const TaskManager = ({ user, onLogout, tasks, onAddTask, onUpdateTask, onDeleteTask }) => {
  const [filter, setFilter] = useState('all');
  const [newTask, setNewTask] = useState({ title: '', priority: 'medium', category: 'general', dueDate: '' });
  const [editingId, setEditingId] = useState(null);

  const filteredTasks = tasks.filter(task => {
    if (filter === 'completed') return task.completed;
    if (filter === 'pending') return !task.completed;
    if (filter === 'high') return task.priority === 'high';
    return true;
  });

  const stats = {
    total: tasks.length,
    completed: tasks.filter(t => t.completed).length,
    pending: tasks.filter(t => !t.completed).length,
    high: tasks.filter(t => t.priority === 'high').length,
  };

  return (
    <div className="app-container">
      <div className="header">
        <h1>📋 Task Manager</h1>
        <div className="header-right">
          <div className="user-info">
            <p>Welcome back!</p>
            <strong>{user.name}</strong>
          </div>
          <button className="btn-logout" onClick={onLogout}>
            Logout
          </button>
        </div>
      </div>

      <div className="main-content">
        {/* Sidebar */}
        <div className="sidebar">
          <h3>Filters</h3>
          <button
            className={`filter-btn ${filter === 'all' ? 'active' : ''}`}
            onClick={() => setFilter('all')}
          >
            📌 All Tasks
          </button>
          <button
            className={`filter-btn ${filter === 'pending' ? 'active' : ''}`}
            onClick={() => setFilter('pending')}
          >
            ⏳ Pending
          </button>
          <button
            className={`filter-btn ${filter === 'completed' ? 'active' : ''}`}
            onClick={() => setFilter('completed')}
          >
            ✅ Completed
          </button>
          <button
            className={`filter-btn ${filter === 'high' ? 'active' : ''}`}
            onClick={() => setFilter('high')}
          >
            🔴 High Priority
          </button>

          <div className="stats">
            <h3>📊 Stats</h3>
            <div className="stat-item">
              <span>Total Tasks</span>
              <span className="stat-number">{stats.total}</span>
            </div>
            <div className="stat-item">
              <span>Completed</span>
              <span className="stat-number">{stats.completed}</span>
            </div>
            <div className="stat-item">
              <span>Pending</span>
              <span className="stat-number">{stats.pending}</span>
            </div>
            <div className="stat-item">
              <span>High Priority</span>
              <span className="stat-number">{stats.high}</span>
            </div>
          </div>
        </div>

        {/* Main Task Section */}
        <div className="task-section">
          <div className="task-header">
            <h2>Your Tasks</h2>
          </div>

          {/* Add Task Form */}
          <div className="add-task-form">
            <div className="form-row">
              <input
                className="form-input"
                placeholder="What's your next task?"
                value={newTask.title}
                onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
              />
              <select
                className="form-input"
                value={newTask.priority}
                onChange={(e) => setNewTask({ ...newTask, priority: e.target.value })}
              >
                <option value="low">🟢 Low</option>
                <option value="medium">🟡 Medium</option>
                <option value="high">🔴 High</option>
              </select>
              <input
                className="form-input"
                type="date"
                value={newTask.dueDate}
                onChange={(e) => setNewTask({ ...newTask, dueDate: e.target.value })}
              />
            </div>
            <button
              className="btn-add-task"
              onClick={() => {
                if (newTask.title.trim()) {
                  onAddTask(newTask);
                  setNewTask({ title: '', priority: 'medium', category: 'general', dueDate: '' });
                }
              }}
            >
              ➕ Add Task
            </button>
          </div>

          {/* Tasks List */}
          {filteredTasks.length > 0 ? (
            <div className="tasks-list">
              {filteredTasks.map(task => (
                <div key={task.id} className={`task-item ${task.completed ? 'completed' : ''}`}>
                  <div className="task-content">
                    <div className="task-title">{task.title}</div>
                    {task.description && <div className="task-description">{task.description}</div>}
                    <div className="task-meta">
                      <span className="task-badge badge-priority">
                        {task.priority === 'high' ? '🔴' : task.priority === 'medium' ? '🟡' : '🟢'} {task.priority}
                      </span>
                      <span className="task-badge badge-category">📂 {task.category}</span>
                      {task.dueDate && <span className="task-badge badge-due">📅 {task.dueDate}</span>}
                    </div>
                  </div>
                  <div className="task-actions">
                    <button
                      className="icon-btn"
                      onClick={() => onUpdateTask(task.id, { completed: !task.completed })}
                    >
                      {task.completed ? '↩️ Undo' : '✅ Done'}
                    </button>
                    <button
                      className="icon-btn"
                      onClick={() => onDeleteTask(task.id)}
                    >
                      🗑️ Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="empty-state">
              <div className="empty-state-icon">📭</div>
              <h3>No tasks yet</h3>
              <p>Create your first task to get started!</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// ==================== MAIN APP ====================

export default function TaskApp() {
  const [isRegister, setIsRegister] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null);
  const [tasks, setTasks] = useState([]);
  const wsRef = useRef(null);

  const API_URL = 'http://localhost:5000/api';

  // Authentication
  const handleAuth = async (formData, isRegisterMode) => {
    const endpoint = isRegisterMode ? '/auth/register' : '/auth/login';
    try {
      const response = await fetch(`${API_URL}${endpoint}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      const data = await response.json();
      if (response.ok) {
        localStorage.setItem('token', data.token);
        setUser(data.user);
        setIsAuthenticated(true);
        fetchTasks(data.token);
        connectWebSocket(data.token);
      }
    } catch (error) {
      console.error('Auth error:', error);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    setIsAuthenticated(false);
    setUser(null);
    setTasks([]);
    if (wsRef.current) wsRef.current.close();
  };

  // Fetch Tasks
  const fetchTasks = async (token) => {
    try {
      const response = await fetch(`${API_URL}/tasks`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await response.json();
      setTasks(data);
    } catch (error) {
      console.error('Fetch error:', error);
    }
  };

  // CRUD Operations
  const handleAddTask = async (taskData) => {
    const token = localStorage.getItem('token');
    try {
      const response = await fetch(`${API_URL}/tasks`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(taskData),
      });
      const newTask = await response.json();
      setTasks([...tasks, newTask]);
    } catch (error) {
      console.error('Add task error:', error);
    }
  };

  const handleUpdateTask = async (taskId, updates) => {
    const token = localStorage.getItem('token');
    try {
      const response = await fetch(`${API_URL}/tasks/${taskId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(updates),
      });
      const updated = await response.json();
      setTasks(tasks.map(t => (t.id === taskId ? updated : t)));
    } catch (error) {
      console.error('Update error:', error);
    }
  };

  const handleDeleteTask = async (taskId) => {
    const token = localStorage.getItem('token');
    try {
      await fetch(`${API_URL}/tasks/${taskId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      setTasks(tasks.filter(t => t.id !== taskId));
    } catch (error) {
      console.error('Delete error:', error);
    }
  };

  // WebSocket Connection
  const connectWebSocket = (token) => {
    wsRef.current = new WebSocket('ws://localhost:5000');
    wsRef.current.onopen = () => {
      wsRef.current.send(JSON.stringify({ type: 'auth', token }));
    };
    wsRef.current.onmessage = (event) => {
      const { type, data } = JSON.parse(event.data);
      if (type === 'task-created') setTasks([...tasks, data]);
      else if (type === 'task-updated') setTasks(tasks.map(t => (t.id === data.id ? data : t)));
      else if (type === 'task-deleted') setTasks(tasks.filter(t => t.id !== data.id));
    };
  };

  // Check Authentication on Mount
  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      setIsAuthenticated(true);
      fetchTasks(token);
      connectWebSocket(token);
    }
  }, []);

  return (
    <>
      <style>{styles}</style>
      {!isAuthenticated ? (
        <AuthScreen
          onLogin={handleAuth}
          onRegisterToggle={() => setIsRegister(!isRegister)}
          isRegister={isRegister}
        />
      ) : (
        <TaskManager
          user={user}
          onLogout={handleLogout}
          tasks={tasks}
          onAddTask={handleAddTask}
          onUpdateTask={handleUpdateTask}
          onDeleteTask={handleDeleteTask}
        />
      )}
    </>
  );
}
