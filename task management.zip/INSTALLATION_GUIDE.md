# 🚀 Task Manager - Installation & Setup Guide

## Prerequisites

Before you start, make sure you have:
- **Node.js** (v14 or higher) - [Download](https://nodejs.org/)
- **npm** or **yarn** - Comes with Node.js
- **Git** - [Download](https://git-scm.com/)
- A code editor (VS Code recommended)
- Command line terminal

## Step 1: Project Setup

### Option A: From Scratch

```bash
# Create project directory
mkdir task-manager-app
cd task-manager-app

# Initialize git
git init

# Create folder structure
mkdir backend frontend
```

### Option B: Clone Repository (if available)

```bash
git clone <repository-url>
cd task-manager-app
```

## Step 2: Backend Setup

### 2.1 Navigate to backend directory

```bash
cd backend
```

### 2.2 Initialize Node project

```bash
npm init -y
```

### 2.3 Install dependencies

```bash
npm install express cors jsonwebtoken bcryptjs ws dotenv
npm install --save-dev nodemon
```

### 2.4 Create project structure

```bash
mkdir middleware utils
touch server.js
touch middleware/auth.js
touch utils/validators.js
touch .env
touch .gitignore
```

### 2.5 Configure environment variables

Create `.env` file:

```env
PORT=5000
NODE_ENV=development
JWT_SECRET=your-super-secret-jwt-key-change-this
REFRESH_SECRET=your-super-secret-refresh-key
JWT_EXPIRY=1h
CORS_ORIGIN=http://localhost:3000
```

⚠️ **IMPORTANT**: Change the JWT secrets to random strings for production!

Generate secure random strings:
```bash
# On macOS/Linux
openssl rand -base64 32

# On Windows PowerShell
[Convert]::ToBase64String((1..32 | ForEach-Object { [byte](Get-Random -Maximum 256) }))
```

### 2.6 Update package.json scripts

```json
{
  "scripts": {
    "start": "node server.js",
    "dev": "nodemon server.js",
    "test": "echo \"Error: no test specified\" && exit 1"
  }
}
```

### 2.7 Create .gitignore

```
node_modules/
.env
.env.local
.DS_Store
*.log
```

### 2.8 Add code files

Copy the provided files:
- `server.js` - Main server file
- `middleware/auth.js` - Authentication middleware
- `utils/validators.js` - Validation utilities

### 2.9 Start backend server

```bash
npm run dev
```

Expected output:
```
✨ Task Manager Server running on port 5000
📡 WebSocket available at ws://localhost:5000
```

## Step 3: Frontend Setup

### 3.1 Navigate to frontend directory

```bash
cd ../frontend
```

### 3.2 Create React app

```bash
npx create-react-app .
# OR if you already have a directory
npx create-react-app task-manager-frontend
cd task-manager-frontend
```

### 3.3 Install additional dependencies

```bash
npm install axios react-router-dom
```

### 3.4 Configure environment variables

Create `.env` file:

```env
REACT_APP_API_URL=http://localhost:5000/api
REACT_APP_WS_URL=ws://localhost:5000
REACT_APP_ENABLE_REAL_TIME_UPDATES=true
REACT_APP_TOKEN_STORAGE_KEY=task_manager_token
REACT_APP_USER_STORAGE_KEY=task_manager_user
```

### 3.5 Create project structure

```bash
mkdir -p src/components src/services src/pages src/hooks src/context
touch src/services/api.js
touch .env
```

### 3.6 Add code files

Copy the provided files:
- `src/services/api.js` - API service layer
- `TaskApp.jsx` or modular components

### 3.7 Update src/index.js

```javascript
import React from 'react';
import ReactDOM from 'react-dom/client';
import TaskApp from './components/TaskApp';
import './index.css';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <TaskApp />
  </React.StrictMode>
);
```

### 3.8 Start frontend server

```bash
npm start
```

This will open `http://localhost:3000` in your browser.

## Step 4: Verify Installation

### Backend Verification

Test the API endpoints:

```bash
# Register a user
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "Test1234",
    "name": "Test User"
  }'

# Login
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "Test1234"
  }'
```

Or use Postman/Thunder Client for easier testing.

### Frontend Verification

1. Open `http://localhost:3000`
2. You should see the login/register screen
3. Try registering a new account
4. Verify you can create, update, and delete tasks

## Step 5: Development Workflow

### Running Both Servers

You can run them in separate terminals:

**Terminal 1 - Backend:**
```bash
cd backend
npm run dev
```

**Terminal 2 - Frontend:**
```bash
cd frontend
npm start
```

### Or use Concurrently (Optional)

From root directory:

```bash
npm install -D concurrently
```

Update root `package.json`:
```json
{
  "scripts": {
    "dev": "concurrently \"cd backend && npm run dev\" \"cd frontend && npm start\"",
    "backend": "cd backend && npm run dev",
    "frontend": "cd frontend && npm start"
  }
}
```

Then run:
```bash
npm run dev
```

## Troubleshooting

### Port 5000 Already in Use

**macOS/Linux:**
```bash
lsof -i :5000
kill -9 <PID>
```

**Windows (PowerShell):**
```powershell
netstat -ano | findstr :5000
taskkill /PID <PID> /F
```

### CORS Errors

Ensure your backend has CORS enabled:
```javascript
const cors = require('cors');
app.use(cors({
  origin: 'http://localhost:3000',
  credentials: true
}));
```

### WebSocket Connection Failed

1. Ensure backend is running on port 5000
2. Check firewall settings
3. Look at browser console for error messages

### Module Not Found Errors

```bash
# Reinstall dependencies
rm -rf node_modules package-lock.json
npm install
```

### Token Issues

Clear localStorage and login again:
```javascript
localStorage.clear()
```

## Database Integration (Optional)

### Using MongoDB

1. Install MongoDB locally or use MongoDB Atlas
2. Add to `server.js`:

```bash
npm install mongoose
```

3. Connect in server:
```javascript
const mongoose = require('mongoose');
mongoose.connect(process.env.DATABASE_URL);
```

4. Create models for Users and Tasks

### Using PostgreSQL

```bash
npm install pg sequelize
```

## Production Deployment

### Backend (Heroku)

```bash
# Login to Heroku
heroku login

# Create app
heroku create your-app-name

# Deploy
git push heroku main

# Set environment variables
heroku config:set JWT_SECRET=your-secret
```

### Frontend (Vercel)

```bash
# Login to Vercel
npm i -g vercel
vercel login

# Deploy
vercel
```

## Security Checklist

- [ ] Change JWT secrets
- [ ] Use HTTPS in production
- [ ] Implement rate limiting
- [ ] Add input validation
- [ ] Use environment variables for secrets
- [ ] Enable CORS only for trusted origins
- [ ] Implement CSRF protection
- [ ] Hash passwords (using bcryptjs)
- [ ] Validate all user inputs
- [ ] Use secure headers (helmet)

## Project File Checklist

### Backend Files
- [ ] `server.js` - Main application
- [ ] `middleware/auth.js` - Authentication
- [ ] `utils/validators.js` - Validation
- [ ] `package.json` - Dependencies
- [ ] `.env` - Environment variables
- [ ] `.gitignore` - Git ignore rules

### Frontend Files
- [ ] `src/App.jsx` or `TaskApp.jsx`
- [ ] `src/services/api.js` - API calls
- [ ] `src/index.js` - Entry point
- [ ] `src/index.css` - Styles
- [ ] `package.json` - Dependencies
- [ ] `.env` - Environment variables
- [ ] `.gitignore` - Git ignore rules

## Next Steps

1. ✅ Complete basic setup
2. ✅ Test authentication
3. ✅ Test CRUD operations
4. ✅ Implement additional features:
   - [ ] Task categories
   - [ ] Task filtering
   - [ ] Due date notifications
   - [ ] Task sharing
   - [ ] Dark mode
   - [ ] User profile
5. ✅ Add database
6. ✅ Deploy to production

## Useful Commands

```bash
# Backend
npm run dev          # Start with nodemon
npm start           # Start normally
npm test            # Run tests

# Frontend
npm start           # Start dev server
npm run build       # Production build
npm test            # Run tests
npm run eject       # Eject from CRA (irreversible!)

# Both
npm run dev         # Run with concurrently
```

## Learning Resources

- [Express.js Docs](https://expressjs.com/)
- [React Docs](https://react.dev/)
- [JWT.io](https://jwt.io/)
- [WebSocket API](https://developer.mozilla.org/en-US/docs/Web/API/WebSocket)
- [REST API Design](https://restfulapi.net/)
- [Node.js Best Practices](https://github.com/goldbergyoni/nodebestpractices)

## Need Help?

1. Check the troubleshooting section
2. Look at browser console for errors
3. Check server terminal for logs
4. Verify environment variables are set
5. Test API endpoints with Postman

---

**Happy Coding! 🎉**
