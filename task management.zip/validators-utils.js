// utils/validators.js - Input Validation & Error Handling

/**
 * Validate Email Format
 */
const isValidEmail = (email) => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email) && email.length <= 255;
};

/**
 * Validate Password Strength
 * Requirements:
 * - Minimum 8 characters
 * - At least one uppercase letter
 * - At least one lowercase letter
 * - At least one number
 */
const isValidPassword = (password) => {
  if (!password || password.length < 8) return false;
  const hasUpperCase = /[A-Z]/.test(password);
  const hasLowerCase = /[a-z]/.test(password);
  const hasNumber = /[0-9]/.test(password);
  return hasUpperCase && hasLowerCase && hasNumber;
};

/**
 * Validate Task Title
 */
const isValidTaskTitle = (title) => {
  return title && typeof title === 'string' && title.trim().length > 0 && title.length <= 255;
};

/**
 * Validate Task Description
 */
const isValidTaskDescription = (description) => {
  return !description || (typeof description === 'string' && description.length <= 5000);
};

/**
 * Validate Priority
 */
const isValidPriority = (priority) => {
  const validPriorities = ['low', 'medium', 'high'];
  return validPriorities.includes(priority);
};

/**
 * Validate Category
 */
const isValidCategory = (category) => {
  const validCategories = ['work', 'personal', 'health', 'finance', 'general'];
  return validCategories.includes(category);
};

/**
 * Validate Due Date
 */
const isValidDueDate = (dueDate) => {
  if (!dueDate) return true; // Optional field
  const date = new Date(dueDate);
  return !isNaN(date.getTime());
};

/**
 * Validate User Registration Data
 */
const validateRegistration = (data) => {
  const errors = {};

  if (!data.name || data.name.trim().length === 0) {
    errors.name = 'Name is required';
  } else if (data.name.length > 100) {
    errors.name = 'Name must be less than 100 characters';
  }

  if (!data.email) {
    errors.email = 'Email is required';
  } else if (!isValidEmail(data.email)) {
    errors.email = 'Invalid email format';
  }

  if (!data.password) {
    errors.password = 'Password is required';
  } else if (!isValidPassword(data.password)) {
    errors.password = 'Password must be at least 8 characters with uppercase, lowercase, and number';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
};

/**
 * Validate User Login Data
 */
const validateLogin = (data) => {
  const errors = {};

  if (!data.email) {
    errors.email = 'Email is required';
  } else if (!isValidEmail(data.email)) {
    errors.email = 'Invalid email format';
  }

  if (!data.password) {
    errors.password = 'Password is required';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
};

/**
 * Validate Task Creation Data
 */
const validateTaskCreation = (data) => {
  const errors = {};

  if (!isValidTaskTitle(data.title)) {
    errors.title = 'Title is required and must be less than 255 characters';
  }

  if (!isValidTaskDescription(data.description)) {
    errors.description = 'Description must be less than 5000 characters';
  }

  if (data.priority && !isValidPriority(data.priority)) {
    errors.priority = 'Invalid priority level';
  }

  if (data.category && !isValidCategory(data.category)) {
    errors.category = 'Invalid category';
  }

  if (data.dueDate && !isValidDueDate(data.dueDate)) {
    errors.dueDate = 'Invalid due date';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
};

/**
 * Validate Task Update Data
 */
const validateTaskUpdate = (data) => {
  const errors = {};

  if (data.title !== undefined && !isValidTaskTitle(data.title)) {
    errors.title = 'Title must be less than 255 characters';
  }

  if (data.description !== undefined && !isValidTaskDescription(data.description)) {
    errors.description = 'Description must be less than 5000 characters';
  }

  if (data.priority !== undefined && !isValidPriority(data.priority)) {
    errors.priority = 'Invalid priority level';
  }

  if (data.category !== undefined && !isValidCategory(data.category)) {
    errors.category = 'Invalid category';
  }

  if (data.dueDate !== undefined && !isValidDueDate(data.dueDate)) {
    errors.dueDate = 'Invalid due date';
  }

  if (data.completed !== undefined && typeof data.completed !== 'boolean') {
    errors.completed = 'Completed must be a boolean';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
};

/**
 * Sanitize User Data
 * Remove sensitive fields before sending to client
 */
const sanitizeUser = (user) => {
  const { password, ...safeUser } = user;
  return safeUser;
};

/**
 * Sanitize Task Data
 */
const sanitizeTask = (task) => {
  return {
    ...task,
    createdAt: new Date(task.createdAt).toISOString(),
    updatedAt: new Date(task.updatedAt).toISOString(),
  };
};

/**
 * API Response Helper
 */
const sendResponse = (res, status, success, message, data = null) => {
  res.status(status).json({
    success,
    message,
    data,
    timestamp: new Date().toISOString(),
  });
};

/**
 * Error Response Helper
 */
const sendError = (res, status, message, errors = null, code = null) => {
  res.status(status).json({
    success: false,
    message,
    errors,
    code,
    timestamp: new Date().toISOString(),
  });
};

/**
 * Async Error Handler
 * Wraps async route handlers to catch errors
 */
const asyncHandler = (fn) => {
  return (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
};

module.exports = {
  // Validators
  isValidEmail,
  isValidPassword,
  isValidTaskTitle,
  isValidTaskDescription,
  isValidPriority,
  isValidCategory,
  isValidDueDate,

  // Complex validations
  validateRegistration,
  validateLogin,
  validateTaskCreation,
  validateTaskUpdate,

  // Sanitizers
  sanitizeUser,
  sanitizeTask,

  // Response helpers
  sendResponse,
  sendError,
  asyncHandler,
};
