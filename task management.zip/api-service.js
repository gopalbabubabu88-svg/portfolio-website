// src/services/api.js - API Service Layer

import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';
const WS_URL = process.env.REACT_APP_WS_URL || 'ws://localhost:5000';

// Create axios instance with default config
const apiClient = axios.create({
  baseURL: API_URL,
  timeout: process.env.REACT_APP_API_TIMEOUT || 30000,
  headers: {
    'Content-Type': 'application/json',
  },
});

/**
 * Request Interceptor
 * Add token to all requests
 */
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem(process.env.REACT_APP_TOKEN_STORAGE_KEY || 'token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

/**
 * Response Interceptor
 * Handle common error responses
 */
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Token expired or invalid
      localStorage.removeItem(process.env.REACT_APP_TOKEN_STORAGE_KEY || 'token');
      localStorage.removeItem(process.env.REACT_APP_USER_STORAGE_KEY || 'user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// ==================== AUTHENTICATION SERVICES ====================

/**
 * Register a new user
 */
export const authService = {
  register: async (userData) => {
    try {
      const response = await apiClient.post('/auth/register', userData);
      if (response.data.token) {
        localStorage.setItem(
          process.env.REACT_APP_TOKEN_STORAGE_KEY || 'token',
          response.data.token
        );
        localStorage.setItem(
          process.env.REACT_APP_USER_STORAGE_KEY || 'user',
          JSON.stringify(response.data.user)
        );
      }
      return response.data;
    } catch (error) {
      throw error.response?.data || { error: 'Registration failed' };
    }
  },

  /**
   * Login user
   */
  login: async (credentials) => {
    try {
      const response = await apiClient.post('/auth/login', credentials);
      if (response.data.token) {
        localStorage.setItem(
          process.env.REACT_APP_TOKEN_STORAGE_KEY || 'token',
          response.data.token
        );
        localStorage.setItem(
          process.env.REACT_APP_USER_STORAGE_KEY || 'user',
          JSON.stringify(response.data.user)
        );
      }
      return response.data;
    } catch (error) {
      throw error.response?.data || { error: 'Login failed' };
    }
  },

  /**
   * Get current user
   */
  getCurrentUser: async () => {
    try {
      const response = await apiClient.get('/auth/me');
      return response.data;
    } catch (error) {
      throw error.response?.data || { error: 'Failed to fetch user' };
    }
  },

  /**
   * Logout user
   */
  logout: () => {
    localStorage.removeItem(process.env.REACT_APP_TOKEN_STORAGE_KEY || 'token');
    localStorage.removeItem(process.env.REACT_APP_USER_STORAGE_KEY || 'user');
  },

  /**
   * Check if user is authenticated
   */
  isAuthenticated: () => {
    return !!localStorage.getItem(process.env.REACT_APP_TOKEN_STORAGE_KEY || 'token');
  },

  /**
   * Get stored user from localStorage
   */
  getStoredUser: () => {
    const user = localStorage.getItem(process.env.REACT_APP_USER_STORAGE_KEY || 'user');
    return user ? JSON.parse(user) : null;
  },

  /**
   * Get token from localStorage
   */
  getToken: () => {
    return localStorage.getItem(process.env.REACT_APP_TOKEN_STORAGE_KEY || 'token');
  },
};

// ==================== TASK SERVICES ====================

export const taskService = {
  /**
   * Get all tasks
   */
  getAll: async () => {
    try {
      const response = await apiClient.get('/tasks');
      return response.data;
    } catch (error) {
      throw error.response?.data || { error: 'Failed to fetch tasks' };
    }
  },

  /**
   * Get single task
   */
  getById: async (taskId) => {
    try {
      const response = await apiClient.get(`/tasks/${taskId}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || { error: 'Failed to fetch task' };
    }
  },

  /**
   * Create new task
   */
  create: async (taskData) => {
    try {
      const response = await apiClient.post('/tasks', taskData);
      return response.data;
    } catch (error) {
      throw error.response?.data || { error: 'Failed to create task' };
    }
  },

  /**
   * Update task
   */
  update: async (taskId, updates) => {
    try {
      const response = await apiClient.put(`/tasks/${taskId}`, updates);
      return response.data;
    } catch (error) {
      throw error.response?.data || { error: 'Failed to update task' };
    }
  },

  /**
   * Delete task
   */
  delete: async (taskId) => {
    try {
      const response = await apiClient.delete(`/tasks/${taskId}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || { error: 'Failed to delete task' };
    }
  },

  /**
   * Toggle task completion status
   */
  toggleComplete: async (taskId, completed) => {
    return taskService.update(taskId, { completed });
  },

  /**
   * Get tasks by priority
   */
  getByPriority: async (priority) => {
    try {
      const allTasks = await taskService.getAll();
      return allTasks.filter(task => task.priority === priority);
    } catch (error) {
      throw error;
    }
  },

  /**
   * Get completed tasks
   */
  getCompleted: async () => {
    try {
      const allTasks = await taskService.getAll();
      return allTasks.filter(task => task.completed);
    } catch (error) {
      throw error;
    }
  },

  /**
   * Get pending tasks
   */
  getPending: async () => {
    try {
      const allTasks = await taskService.getAll();
      return allTasks.filter(task => !task.completed);
    } catch (error) {
      throw error;
    }
  },
};

// ==================== WEBSOCKET SERVICE ====================

class WebSocketService {
  constructor() {
    this.ws = null;
    this.listeners = new Map();
    this.isConnected = false;
    this.reconnectAttempts = 0;
    this.maxReconnectAttempts = 5;
  }

  /**
   * Connect to WebSocket server
   */
  connect(token) {
    return new Promise((resolve, reject) => {
      try {
        this.ws = new WebSocket(WS_URL);

        this.ws.onopen = () => {
          console.log('WebSocket connected');
          this.isConnected = true;
          this.reconnectAttempts = 0;

          // Send authentication message
          this.send({ type: 'auth', token });
          resolve();
        };

        this.ws.onmessage = (event) => {
          const data = JSON.parse(event.data);
          this.handleMessage(data);
        };

        this.ws.onerror = (error) => {
          console.error('WebSocket error:', error);
          this.isConnected = false;
          reject(error);
        };

        this.ws.onclose = () => {
          console.log('WebSocket disconnected');
          this.isConnected = false;
          this.attemptReconnect(token);
        };
      } catch (error) {
        reject(error);
      }
    });
  }

  /**
   * Attempt to reconnect
   */
  attemptReconnect(token) {
    if (this.reconnectAttempts < this.maxReconnectAttempts) {
      this.reconnectAttempts++;
      const delay = Math.min(1000 * Math.pow(2, this.reconnectAttempts), 30000);
      console.log(`Attempting to reconnect in ${delay}ms...`);

      setTimeout(() => {
        this.connect(token).catch(() => {
          console.error('Reconnection failed');
        });
      }, delay);
    }
  }

  /**
   * Handle incoming WebSocket messages
   */
  handleMessage(data) {
    const { type, data: messageData } = data;

    // Notify all listeners of this message type
    if (this.listeners.has(type)) {
      const callbacks = this.listeners.get(type);
      callbacks.forEach(callback => callback(messageData));
    }
  }

  /**
   * Send message through WebSocket
   */
  send(message) {
    if (this.isConnected && this.ws) {
      this.ws.send(JSON.stringify(message));
    } else {
      console.warn('WebSocket is not connected');
    }
  }

  /**
   * Subscribe to a message type
   */
  on(type, callback) {
    if (!this.listeners.has(type)) {
      this.listeners.set(type, []);
    }
    this.listeners.get(type).push(callback);

    // Return unsubscribe function
    return () => {
      const callbacks = this.listeners.get(type);
      const index = callbacks.indexOf(callback);
      if (index > -1) {
        callbacks.splice(index, 1);
      }
    };
  }

  /**
   * Unsubscribe from a message type
   */
  off(type, callback) {
    if (this.listeners.has(type)) {
      const callbacks = this.listeners.get(type);
      const index = callbacks.indexOf(callback);
      if (index > -1) {
        callbacks.splice(index, 1);
      }
    }
  }

  /**
   * Disconnect WebSocket
   */
  disconnect() {
    if (this.ws) {
      this.ws.close();
      this.ws = null;
      this.isConnected = false;
    }
  }
}

// Export singleton instance
export const wsService = new WebSocketService();

export default apiClient;
